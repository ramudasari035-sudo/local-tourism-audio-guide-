# Local Tourism Audio Guide Platform

A hackathon-ready full-stack application matching the given problem statement.

## Stack
- Backend: Java 17, Spring Boot, Spring Data JPA, MySQL
- Frontend: React + Vite
- REST API: React -> Spring Boot -> JPA/MySQL
- Audio: HTML5 audio player using a URL stored with each heritage site

## Features
- Heritage/tourist site listing
- Search and language filtering
- Site details: description, history, navigation information
- Audio guide playback
- Visit/history recording
- Responsive React UI
- Validation and meaningful HTTP responses
- MySQL persistence with JPA/Hibernate
- Sample seed data

## Run backend

1. Create a MySQL database named `tourism_guide`.
2. Open `backend/src/main/resources/application.properties` and set your MySQL username/password.
3. Run:

```bash
cd backend
mvn spring-boot:run
```

Backend: `http://localhost:8080`

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

The frontend expects the backend at `http://localhost:8080`.

## API endpoints

- `GET /api/sites`
- `GET /api/sites/{id}`
- `GET /api/sites/search?q=&language=`
- `POST /api/sites`
- `POST /api/sites/{id}/history`

## Demo audio
The sample records use public MP3 URLs. For a final submission, replace them with your own hosted audio files or a cloud storage URL.
