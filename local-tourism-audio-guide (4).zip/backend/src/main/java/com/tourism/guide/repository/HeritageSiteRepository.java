package com.tourism.guide.repository;

import com.tourism.guide.model.HeritageSite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface HeritageSiteRepository extends JpaRepository<HeritageSite, Long> {
    @Query("select s from HeritageSite s where lower(s.name) like lower(concat('%', :q, '%')) " +
           "or lower(s.location) like lower(concat('%', :q, '%'))")
    List<HeritageSite> search(@Param("q") String q);

    List<HeritageSite> findByLanguageIgnoreCase(String language);
}
