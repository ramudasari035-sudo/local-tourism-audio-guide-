package com.tourism.guide.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "heritage_sites")
public class HeritageSite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String name;
    @NotBlank
    private String location;
    @NotBlank
    private String language;

    @Column(length = 2000)
    private String description;

    @Column(length = 3000)
    private String history;

    @Column(length = 3000)
    private String navigationInfo;

    private String audioUrl;
    private String mapUrl;

    public HeritageSite() {}

    public HeritageSite(String name, String location, String language,
                         String description, String history,
                         String navigationInfo, String audioUrl, String mapUrl) {
        this.name = name;
        this.location = location;
        this.language = language;
        this.description = description;
        this.history = history;
        this.navigationInfo = navigationInfo;
        this.audioUrl = audioUrl;
        this.mapUrl = mapUrl;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getLocation() { return location; }
    public String getLanguage() { return language; }
    public String getDescription() { return description; }
    public String getHistory() { return history; }
    public String getNavigationInfo() { return navigationInfo; }
    public String getAudioUrl() { return audioUrl; }
    public String getMapUrl() { return mapUrl; }

    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setLocation(String location) { this.location = location; }
    public void setLanguage(String language) { this.language = language; }
    public void setDescription(String description) { this.description = description; }
    public void setHistory(String history) { this.history = history; }
    public void setNavigationInfo(String navigationInfo) { this.navigationInfo = navigationInfo; }
    public void setAudioUrl(String audioUrl) { this.audioUrl = audioUrl; }
    public void setMapUrl(String mapUrl) { this.mapUrl = mapUrl; }
}
