package com.tourism.guide.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "visit_history")
public class VisitHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long siteId;
    private String siteName;
    private LocalDateTime visitedAt;

    public VisitHistory() {}

    public VisitHistory(Long siteId, String siteName) {
        this.siteId = siteId;
        this.siteName = siteName;
        this.visitedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Long getSiteId() { return siteId; }
    public String getSiteName() { return siteName; }
    public LocalDateTime getVisitedAt() { return visitedAt; }
}
