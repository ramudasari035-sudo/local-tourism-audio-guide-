package com.tourism.guide;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.tourism.guide.model.HeritageSite;
import com.tourism.guide.repository.HeritageSiteRepository;

@SpringBootApplication
public class TourismGuideApplication {

    public static void main(String[] args) {
        SpringApplication.run(TourismGuideApplication.class, args);
    }

    @Bean
    CommandLineRunner seed(HeritageSiteRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new HeritageSite(
                    "Tirumala Temple",
                    "Tirupati, Andhra Pradesh",
                    "Telugu",
                    "Sri Venkateswara Swamy Temple is one of India's most visited pilgrimage destinations.",
                    "The temple has a long history associated with Lord Venkateswara and the Tirumala hills.",
                    "Travel to Tirumala from Tirupati by bus, taxi or private vehicle. Follow local visitor and temple entry instructions.",
                    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
                    "https://maps.google.com/?q=Tirumala+Temple"
                ));
                repository.save(new HeritageSite(
                    "Charminar",
                    "Hyderabad, Telangana",
                    "English",
                    "The Charminar is an iconic monument and landmark in the heart of Hyderabad.",
                    "Built in 1591, the monument is closely connected with the history and development of Hyderabad.",
                    "Located in the Old City. Visitors can reach the site by road and public transport.",
                    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
                    "https://maps.google.com/?q=Charminar"
                ));
                repository.save(new HeritageSite(
                    "Konark Sun Temple",
                    "Konark, Odisha",
                    "English",
                    "A UNESCO World Heritage Site famous for its monumental stone chariot design.",
                    "The temple was built in the 13th century and is dedicated to the Sun God.",
                    "Konark is connected by road with Puri and Bhubaneswar. Check local opening hours before visiting.",
                    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
                    "https://maps.google.com/?q=Konark+Sun+Temple"
                ));
            }
        };
    }
}
