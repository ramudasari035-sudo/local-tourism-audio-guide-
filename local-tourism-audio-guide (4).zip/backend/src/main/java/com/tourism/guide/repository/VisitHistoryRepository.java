package com.tourism.guide.repository;

import com.tourism.guide.model.VisitHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface VisitHistoryRepository extends JpaRepository<VisitHistory, Long> {
    List<VisitHistory> findTop20ByOrderByVisitedAtDesc();
}
