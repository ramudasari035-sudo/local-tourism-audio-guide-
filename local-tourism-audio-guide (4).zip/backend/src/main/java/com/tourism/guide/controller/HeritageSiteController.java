package com.tourism.guide.controller;

import com.tourism.guide.model.HeritageSite;
import com.tourism.guide.model.VisitHistory;
import com.tourism.guide.repository.HeritageSiteRepository;
import com.tourism.guide.repository.VisitHistoryRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sites")
@CrossOrigin(origins = "http://localhost:5173")
public class HeritageSiteController {
    private final HeritageSiteRepository siteRepository;
    private final VisitHistoryRepository historyRepository;

    public HeritageSiteController(HeritageSiteRepository siteRepository,
                                  VisitHistoryRepository historyRepository) {
        this.siteRepository = siteRepository;
        this.historyRepository = historyRepository;
    }

    @GetMapping
    public List<HeritageSite> all() {
        return siteRepository.findAll();
    }

    @GetMapping("/{id}")
    public HeritageSite one(@PathVariable Long id) {
        return siteRepository.findById(id)
                .orElseThrow(() -> new SiteNotFoundException("Heritage site not found"));
    }

    @GetMapping("/search")
    public List<HeritageSite> search(
            @RequestParam(required = false, defaultValue = "") String q,
            @RequestParam(required = false) String language) {

        List<HeritageSite> result = q.isBlank()
                ? siteRepository.findAll()
                : siteRepository.search(q);

        if (language != null && !language.isBlank()) {
            result = result.stream()
                    .filter(s -> s.getLanguage().equalsIgnoreCase(language))
                    .toList();
        }
        return result;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public HeritageSite create(@Valid @RequestBody HeritageSite site) {
        return siteRepository.save(site);
    }

    @PostMapping("/{id}/history")
    @ResponseStatus(HttpStatus.CREATED)
    public VisitHistory recordVisit(@PathVariable Long id) {
        HeritageSite site = siteRepository.findById(id)
                .orElseThrow(() -> new SiteNotFoundException("Heritage site not found"));
        return historyRepository.save(new VisitHistory(site.getId(), site.getName()));
    }

    @GetMapping("/history")
    public List<VisitHistory> history() {
        return historyRepository.findTop20ByOrderByVisitedAtDesc();
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    static class SiteNotFoundException extends RuntimeException {
        SiteNotFoundException(String message) { super(message); }
    }
}
