import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './style.css'

const API = 'http://localhost:8080/api'

function App() {
  const [sites, setSites] = useState([])
  const [selected, setSelected] = useState(null)
  const [query, setQuery] = useState('')
  const [language, setLanguage] = useState('')
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState('')

  async function loadSites() {
    setLoading(true)
    setMessage('')
    try {
      const params = new URLSearchParams()
      if (query) params.set('q', query)
      if (language) params.set('language', language)
      const res = await fetch(`${API}/sites/search?${params}`)
      if (!res.ok) throw new Error('Could not load tourism sites')
      setSites(await res.json())
    } catch (e) {
      setMessage(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function openSite(site) {
    setSelected(site)
    try {
      await fetch(`${API}/sites/${site.id}/history`, { method: 'POST' })
    } catch (_) {}
  }

  useEffect(() => { loadSites() }, [language])

  return (
    <div className="app">
      <header className="hero">
        <div>
          <span className="badge">LOCAL TOURISM • AUDIO GUIDE</span>
          <h1>Heritage Voice</h1>
          <p>Explore India's heritage sites through stories, history and audio guides.</p>
        </div>
        <div className="hero-icon">🎧</div>
      </header>

      <section className="controls">
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && loadSites()}
          placeholder="Search a heritage site or city..."
        />
        <select value={language} onChange={e => setLanguage(e.target.value)}>
          <option value="">All languages</option>
          <option value="English">English</option>
          <option value="Telugu">Telugu</option>
          <option value="Hindi">Hindi</option>
        </select>
        <button onClick={loadSites}>Search</button>
      </section>

      {message && <div className="error">{message}</div>}

      {loading ? <div className="state">Loading heritage sites...</div> :
        sites.length === 0 ? <div className="state">No sites found. Try another search.</div> :
        <main className="grid">
          {sites.map(site => (
            <article className="card" key={site.id}>
              <div className="card-top">
                <span className="tag">{site.language}</span>
                <span>📍</span>
              </div>
              <h2>{site.name}</h2>
              <p className="location">{site.location}</p>
              <p>{site.description}</p>
              <button className="primary" onClick={() => openSite(site)}>Explore & Listen</button>
            </article>
          ))}
        </main>
      }

      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <button className="close" onClick={() => setSelected(null)}>×</button>
            <span className="tag">{selected.language}</span>
            <h2>{selected.name}</h2>
            <p className="location">📍 {selected.location}</p>

            <h3>About</h3>
            <p>{selected.description}</p>

            <h3>History</h3>
            <p>{selected.history}</p>

            <h3>Audio Guide</h3>
            <audio controls src={selected.audioUrl} style={{width:'100%'}}>
              Your browser does not support audio playback.
            </audio>

            <h3>Navigation</h3>
            <p>{selected.navigationInfo}</p>
            <a className="map-btn" href={selected.mapUrl} target="_blank">Open in Maps ↗</a>
          </div>
        </div>
      )}
    </div>
  )
}

createRoot(document.getElementById('root')).render(<App />)
