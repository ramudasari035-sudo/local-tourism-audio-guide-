package com.heritagevoice.repository;

import com.heritagevoice.entity.TouristSite;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TouristSiteRepository extends JpaRepository<TouristSite, Long> {
    List<TouristSite> findByNameContainingIgnoreCaseOrLocationContainingIgnoreCase(String name, String location);
}
