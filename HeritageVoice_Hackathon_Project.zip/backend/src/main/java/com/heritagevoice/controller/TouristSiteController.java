package com.heritagevoice.controller;

import com.heritagevoice.entity.TouristSite;
import com.heritagevoice.service.TouristSiteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/sites")
@CrossOrigin(origins = "http://localhost:5173")
public class TouristSiteController {
    private final TouristSiteService service;
    public TouristSiteController(TouristSiteService service){this.service=service;}

    @GetMapping public List<TouristSite> all(){return service.all();}

    @GetMapping("/{id}") public TouristSite one(@PathVariable Long id){return service.one(id);}

    @GetMapping("/search")
    public List<TouristSite> search(@RequestParam(defaultValue="") String q){return service.search(q);}

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TouristSite create(@Valid @RequestBody TouristSite site){return service.create(site);}
}
