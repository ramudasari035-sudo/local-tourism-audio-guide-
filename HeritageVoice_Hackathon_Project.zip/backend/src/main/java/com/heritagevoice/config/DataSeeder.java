package com.heritagevoice.config;

import com.heritagevoice.entity.TouristSite;
import com.heritagevoice.repository.TouristSiteRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSeeder {
    @Bean
    CommandLineRunner seed(TouristSiteRepository repo) {
        return args -> {
            if (repo.count() > 0) return;
            repo.save(new TouristSite(
                "Undavalli Caves",
                "A remarkable rock-cut cave complex near Vijayawada, known for its architecture and historic sculptures.",
                "The Undavalli Caves are a historic rock-cut complex carved into sandstone. The multi-level structure contains halls, pillars and large sculptural forms and is an important heritage attraction of the Krishna region.",
                "Undavalli, Andhra Pradesh", 16.4957, 80.5792,
                "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=1200&q=80"));
            repo.save(new TouristSite(
                "Amaravati Heritage",
                "Explore the cultural and Buddhist heritage of the Amaravati region.",
                "Amaravati has a long cultural history associated with Buddhism and the ancient Amaravati school of art. The region contains important archaeological and cultural attractions.",
                "Amaravati, Andhra Pradesh", 16.5720, 80.3575,
                "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?auto=format&fit=crop&w=1200&q=80"));
            repo.save(new TouristSite(
                "Kondapalli Fort",
                "A historic hill fort near Vijayawada with panoramic views and cultural significance.",
                "Kondapalli Fort is a historic fortification on a hill near Vijayawada. It is associated with regional dynasties and is also close to the famous Kondapalli toy-making tradition.",
                "Kondapalli, Andhra Pradesh", 16.6195, 80.5315,
                "https://images.unsplash.com/photo-1598091383021-15ddea10925d?auto=format&fit=crop&w=1200&q=80"));
            repo.save(new TouristSite(
                "Kanaka Durga Temple",
                "A major temple overlooking the Krishna River in Vijayawada.",
                "The temple is located on Indrakeeladri hill beside the Krishna River and is one of the prominent pilgrimage destinations in Andhra Pradesh.",
                "Vijayawada, Andhra Pradesh", 16.5159, 80.6167,
                "https://images.unsplash.com/photo-1609766857041-ed402ea8069a?auto=format&fit=crop&w=1200&q=80"));
        };
    }
}
