package com.heritagevoice.service;

import com.heritagevoice.entity.TouristSite;
import com.heritagevoice.repository.TouristSiteRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TouristSiteService {
    private final TouristSiteRepository repo;
    public TouristSiteService(TouristSiteRepository repo){this.repo=repo;}

    public List<TouristSite> all(){ return repo.findAll(); }

    public TouristSite one(Long id){
        return repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Tourist site not found"));
    }

    public List<TouristSite> search(String q){
        if(q == null || q.isBlank()) return all();
        return repo.findByNameContainingIgnoreCaseOrLocationContainingIgnoreCase(q, q);
    }

    public TouristSite create(TouristSite site){ return repo.save(site); }
}
