package com.heritagevoice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeritageVoiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(HeritageVoiceApplication.class, args);
    }
}
