package com.heritagevoice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "tourist_sites")
public class TouristSite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank private String name;

    @Column(length = 3000)
    @NotBlank private String description;

    @Column(length = 6000)
    @NotBlank private String history;

    @NotBlank private String location;

    @NotNull private Double latitude;
    @NotNull private Double longitude;

    private String imageUrl;

    public TouristSite() {}

    public TouristSite(String name, String description, String history, String location,
                       Double latitude, Double longitude, String imageUrl) {
        this.name = name; this.description = description; this.history = history;
        this.location = location; this.latitude = latitude; this.longitude = longitude;
        this.imageUrl = imageUrl;
    }

    public Long getId(){return id;}
    public String getName(){return name;}
    public void setName(String v){name=v;}
    public String getDescription(){return description;}
    public void setDescription(String v){description=v;}
    public String getHistory(){return history;}
    public void setHistory(String v){history=v;}
    public String getLocation(){return location;}
    public void setLocation(String v){location=v;}
    public Double getLatitude(){return latitude;}
    public void setLatitude(Double v){latitude=v;}
    public Double getLongitude(){return longitude;}
    public void setLongitude(Double v){longitude=v;}
    public String getImageUrl(){return imageUrl;}
    public void setImageUrl(String v){imageUrl=v;}
}
