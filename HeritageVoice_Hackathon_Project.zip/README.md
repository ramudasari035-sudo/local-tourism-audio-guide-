# HeritageVoice – Local Tourism Audio Guide

A hackathon-ready full-stack MVP for Problem 09: Local Tourism Audio Guide Platform.

## Stack
- Java 17+
- Spring Boot
- Spring Data JPA / Hibernate
- MySQL
- React + Vite
- REST API

## Features
- Tourist/heritage site listing
- Search
- Site details, history and description
- Language selection
- Audio guide playback
- Google Maps navigation
- Loading, validation and error states
- MySQL persistence

## Run backend
1. Create MySQL database:
   `CREATE DATABASE tourism_db;`
2. Edit `backend/src/main/resources/application.properties` with your MySQL username/password.
3. From `backend` run:
   `mvn spring-boot:run`
4. API: http://localhost:8080/api/sites

## Run frontend
From `frontend`:
```bash
npm install
npm run dev
```
Open the Vite URL shown in the terminal.

## Demo
The application is preloaded with sample Andhra Pradesh heritage/tourism sites. Replace the sample audio files in `backend/src/main/resources/static/audio/` with real Telugu/English/Hindi narration files before the final presentation.
