import React, {useEffect, useState} from 'react';
import {MapPin, Search, Headphones, ArrowLeft, Navigation, Globe2, History, LoaderCircle} from 'lucide-react';

const API='http://localhost:8080/api/sites';

function App(){
  const [sites,setSites]=useState([]);
  const [selected,setSelected]=useState(null);
  const [q,setQ]=useState('');
  const [lang,setLang]=useState('English');
  const [loading,setLoading]=useState(true);
  const [error,setError]=useState('');

  async function load(url=API){
    setLoading(true); setError('');
    try{
      const r=await fetch(url);
      if(!r.ok) throw new Error('Unable to load tourism data');
      setSites(await r.json());
    }catch(e){setError(e.message)}
    finally{setLoading(false)}
  }
  useEffect(()=>{load()},[]);

  function search(){
    const url=q.trim()?`${API}/search?q=${encodeURIComponent(q)}`:API;
    load(url);
  }

  if(selected){
    const maps=`https://www.google.com/maps/dir/?api=1&destination=${selected.latitude},${selected.longitude}`;
    const audio=`/audio/${selected.id}-${lang.toLowerCase()}.mp3`;
    return <div className="app">
      <header><button className="back" onClick={()=>setSelected(null)}><ArrowLeft/> Back</button><b>🏛️ HeritageVoice</b></header>
      <main className="detail">
        <img className="hero" src={selected.imageUrl} />
        <div className="detail-card">
          <span className="tag">HERITAGE SITE</span>
          <h1>{selected.name}</h1>
          <p className="location"><MapPin size={18}/>{selected.location}</p>
          <p>{selected.description}</p>
          <h2><History size={22}/> History</h2><p>{selected.history}</p>
          <div className="guide">
            <div className="guide-title"><Headphones/> Audio Guide</div>
            <select value={lang} onChange={e=>setLang(e.target.value)}>
              <option>English</option><option>Telugu</option><option>Hindi</option>
            </select>
            <audio controls src={audio}/>
            <small>If audio is not available, add the matching MP3 to <code>backend/src/main/resources/static/audio/</code>.</small>
          </div>
          <a className="navigate" href={maps} target="_blank" rel="noreferrer"><Navigation size={18}/> Navigate with Google Maps</a>
        </div>
      </main>
    </div>
  }

  return <div className="app">
    <header><div className="brand">🏛️ <span>HeritageVoice</span></div><div className="lang"><Globe2 size={17}/> Local Tourism Audio Guide</div></header>
    <section className="hero-section">
      <div><span className="eyebrow">DISCOVER • LISTEN • EXPLORE</span><h1>Experience history,<br/><em>one story at a time.</em></h1><p>Explore local heritage sites with descriptions, history, multilingual audio guides and easy navigation.</p></div>
    </section>
    <main>
      <div className="search"><Search/><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&search()} placeholder="Search heritage sites or locations..."/><button onClick={search}>Search</button></div>
      <div className="section-head"><div><h2>Featured Heritage Sites</h2><p>Choose a place and start your audio journey.</p></div></div>
      {error&&<div className="error">{error}. Make sure the Spring Boot backend and MySQL are running.</div>}
      {loading?<div className="loading"><LoaderCircle className="spin"/> Loading sites...</div>:
      <div className="grid">{sites.map(s=><article className="card" key={s.id}>
        <img src={s.imageUrl}/><div className="card-body"><span className="tag">{s.location}</span><h3>{s.name}</h3><p>{s.description}</p><button onClick={()=>setSelected(s)}>Explore site <ArrowLeft className="arrow"/></button></div>
      </article>)}</div>}
    </main>
    <footer>HeritageVoice • Hackathon MVP • Java + Spring Boot + React + MySQL</footer>
  </div>
}
export default App;
